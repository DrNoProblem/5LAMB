const mysql = require('mysql');

// Paramètres de connexion à la base de données
const connection = mysql.createPool({
    connectionLimit: 10, // La limite de connexion pour le pool
    host: process.env.RDS_HOSTNAME, // Variable d'environnement pour l'endpoint RDS
    user: process.env.RDS_USERNAME, // Variable d'environnement pour le nom d'utilisateur RDS
    password: process.env.RDS_PASSWORD, // Variable d'environnement pour le mot de passe RDS
    database: process.env.RDS_DB_NAME, // Variable d'environnement pour le nom de la base de données
    port: 3306 // Variable d'environnement pour le port RDS, habituellement 3306
});


exports.handler = async (event) => {
    const { id } = event;

    // Requête SQL pour récupérer un post
    const sql = 'SELECT * FROM posts WHERE id = ?';

    // Promesse pour gérer la requête SQL
    return new Promise((resolve, reject) => {
        connection.query(sql, [id], (error, results, fields) => {
            if (error) {
                connection.destroy();
                reject(error);
            } else {
                connection.end();
                if (results.length > 0) {
                    resolve({
                        statusCode: 200,
                        body: JSON.stringify(results[0])
                    });
                } else {
                    resolve({
                        statusCode: 404,
                        body: JSON.stringify({ message: 'post not found' })
                    });
                }
            }
        });
    });
};