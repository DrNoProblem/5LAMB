const AWS = require('aws-sdk');
AWS.config.update({ region: 'eu-north-1' }); // Assurez-vous de remplacer par votre région AWS correcte

const cognito = new AWS.CognitoIdentityServiceProvider();

exports.handler = async (event) => {
    let body;
    if (typeof event.body === 'string') {
        body = JSON.parse(event.body); // Parse la chaîne JSON en objet JavaScript
    } else {
        body = event.body; // Utilise directement l'objet JavaScript
    }
    const { username, email, password } = body;
    const userPoolId = 'eu-north-1_TknZ9ViRG'; // Remplacez par votre User Pool ID
    const clientId = '64chunnbvs8k1i6vlrm2u4fj73'; // Remplacez par votre Client ID

    const signUpParams = {
        ClientId: clientId,
        Username: username,
        Password: password,
        UserAttributes: [
            {
                Name: 'email',
                Value: email
            }
            // Ajoutez d'autres attributs ici si nécessaire
        ]
    };

    try {
        const signUpResponse = await cognito.signUp(signUpParams).promise();
        console.log('Sign Up success:', signUpResponse);
        return {
            statusCode: 200,
            body: JSON.stringify({
                message: 'User registration successful',
                data: signUpResponse
            }),
        };
    } catch (error) {
        console.error('Sign Up error:', error);
        return {
            statusCode: error.statusCode || 500,
            body: JSON.stringify({
                message: 'User registration failed',
                error: error.message
            }),
        };
    }
};
