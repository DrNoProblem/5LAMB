const AWS = require('aws-sdk');

const cognito = new AWS.CognitoIdentityServiceProvider();

exports.handler = async (event) => {
    const { username, password, newPassword } = event;

    let params = {
        AuthFlow: 'USER_PASSWORD_AUTH',
        ClientId: '64chunnbvs8k1i6vlrm2u4fj73',
        AuthParameters: {
            USERNAME: username,
            PASSWORD: password
        }
    };

    try {
        let authResponse = await cognito.initiateAuth(params).promise();

        // Gérer le défi NEW_PASSWORD_REQUIRED
        if (authResponse.ChallengeName === 'NEW_PASSWORD_REQUIRED') {
            // Assurez-vous que le nouveau mot de passe est fourni dans l'événement
            if (!newPassword) {
                return {
                    statusCode: 400,
                    body: JSON.stringify({ message: 'New password required' })
                };
            }

            // Paramètres pour répondre au défi
            const challengeResponses = {
                USERNAME: username,
                NEW_PASSWORD: newPassword,
                // Vous pouvez ajouter d'autres attributs si nécessaire
            };

            // Répondre au défi
            const challengeParams = {
                ChallengeName: 'NEW_PASSWORD_REQUIRED',
                ClientId: '64chunnbvs8k1i6vlrm2u4fj73',
                Session: authResponse.Session,
                ChallengeResponses: challengeResponses
            };

            authResponse = await cognito.respondToAuthChallenge(challengeParams).promise();

            return {
                statusCode: 200,
                message: 'Password changed successfully',
                token: JSON.stringify({ 
                    data: authResponse.AuthenticationResult 
                })
            };
        }

        // Connexion réussie, pas de défi
        return {
            statusCode: 200,
            message: 'Login successfully',
            token: JSON.stringify({ 
                data: authResponse.AuthenticationResult 
            }),
        };
    } catch (error) {
        console.error(error);
        return {
            statusCode: error.statusCode || 401,
            body: JSON.stringify({ error: error.message })
        };
    }
};