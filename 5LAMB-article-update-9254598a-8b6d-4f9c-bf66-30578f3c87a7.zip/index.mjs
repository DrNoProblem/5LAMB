import mysql from 'mysql'
// Paramètres de connexion à la base de données
const connection = mysql.createPool({
    connectionLimit: 10, // La limite de connexion pour le pool
    host: process.env.RDS_HOSTNAME, // Variable d'environnement pour l'endpoint RDS
    user: process.env.RDS_USERNAME, // Variable d'environnement pour le nom d'utilisateur RDS
    password: process.env.RDS_PASSWORD, // Variable d'environnement pour le mot de passe RDS
    database: process.env.RDS_DB_NAME, // Variable d'environnement pour le nom de la base de données
    port: 3306 // Variable d'environnement pour le port RDS, habituellement 3306
});

exports.handler = async (event) => {
    const { id, title, author, message } = event;

    // Requête SQL pour mettre à jour un post
    const sql = 'UPDATE posts SET title = ?, author = ?, message = ? WHERE id = ?';

    // Promesse pour gérer la mise à jour SQL
    return new Promise((resolve, reject) => {
        connection.query(sql, [title, author, message, id], (error, results, fields) => {
            if (error) {
                connection.destroy();
                reject(error);
            } else {
                connection.end();
                if (results.affectedRows > 0) {
                    resolve({
                        statusCode: 200,
                        body: JSON.stringify({ message: 'post updated successfully' })
                    });
                } else {
                    resolve({
                        statusCode: 404,
                        body: JSON.stringify({ message: 'post not found' })
                    });
                }
            }
        });
    });
};
