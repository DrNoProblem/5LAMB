const mysql = require('mysql');

// Configuration de la connexion à la base de données
const pool = mysql.createPool({
    connectionLimit: 10, // La limite de connexion pour le pool
    host: process.env.RDS_HOSTNAME, // Variable d'environnement pour l'endpoint RDS
    user: process.env.RDS_USERNAME, // Variable d'environnement pour le nom d'utilisateur RDS
    password: process.env.RDS_PASSWORD, // Variable d'environnement pour le mot de passe RDS
    database: process.env.RDS_DB_NAME, // Variable d'environnement pour le nom de la base de données
    port: 3306 // Variable d'environnement pour le port RDS, habituellement 3306
});

exports.handler = async (event) => {
    // Parsez l'événement qui contient les données de l'article
    let { id, title, author, message } = JSON.parse(event.body);

    // Créez une nouvelle promesse pour gérer l'insertion SQL
    const insertArticle = new Promise((resolve, reject) => {
        pool.query('INSERT INTO articles SET ?', { id, title, author, message }, (error, results, fields) => {
            if (error) {
                return reject(error);
            }
            resolve(results);
        });
    });

    try {
        const results = await insertArticle;
        return {
            statusCode: 200,
            body: JSON.stringify({
                message: 'Nouvel article ajouté avec succès',
                articleId: results.insertId
            }),
        };
    } catch (error) {
        console.error('Erreur d\'insertion:', error);
        return {
            statusCode: 500,
            body: JSON.stringify({
                message: 'Échec de l\'ajout de l\'article',
                error: error.message
            }),
        };
    }
};
